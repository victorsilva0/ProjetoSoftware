package com.premium.outlet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OutletApplication {

	public static void main(String[] args) {
		SpringApplication.run(OutletApplication.class, args);
	}

}
